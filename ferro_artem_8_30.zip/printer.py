import serial
import serial.tools.list_ports
import os
import threading
import time
import pages.viewport
import parse
import pages.debug_terminal
import camera
import PySimpleGUI as sg

PRINTER_CONNECTED = len(serial.tools.list_ports.comports()) > 0
SER = None

REALTIME_MODE = False
PRINTER_HEAD_POS = (0, 0, 0) # last position of printer head

sending_serial = False
curr_index = 0

def init():
    global SER

    if PRINTER_CONNECTED:  # Initialize the printer
        port = str(serial.tools.list_ports.comports()[0])
        port_name = port.split(' ', 1)[0]
        # print(str(serial.tools.list_ports.comports()[0]))
        print(port_name)

        SER = serial.Serial(port_name, 115200)
        SER.write(str.encode("M84 X Y Z S12000\r\n"))
        SER.write(str.encode("G90\r\n"))  # Use absolute positioning
        SER.write(str.encode("G21\r\n"))  # Use millimeters
        #SER.write(str.encode("G01 X0 Y0 F300 \r\n"))




def send_via_serial():
    SER.write(str.encode("\r\n"))

    for instr in parse.INSTRUCTIONS[curr_index:]: #store how many instructions we have passed so far and pick it up after executing capture commands
        curr_index += 1
        SER.write(str.encode(instr.stringify() + "\r\n"))
        if not isinstance(instr, parse.InstructionG0) and not isinstance(instr, parse.InstructionG91):
            pages.debug_terminal.debug_log(instr.stringify())
        if isinstance(instr, parse.InstructionG01):
            global PRINTER_HEAD_POS
            if instr.data['camera'] == True: #check if move command is for camera
                PRINTER_HEAD_POS = (
                    instr.data["x"], 
                    instr.data["y"],
                    instr.data["z"]
                )
                camera.capture_flag = True
                return # jump out of current loop to capture image and set the capture flag and still sending flag to true
            else:
                PRINTER_HEAD_POS = (
                    instr.data["x"],
                    instr.data["y"],
                    instr.data["z"]
                )
        if isinstance(instr, parse.InstructionG0) and pages.viewport.Toggle_Pull:
            PRINTER_HEAD_POS[2] += ( 
                instr.data["z"]
            )
            pages.debug_terminal.syringe_log(instr.stringify())
        if isinstance(instr, parse.InstructionG0) and pages.viewport.Toggle_Push:
            PRINTER_HEAD_POS[2] -= ( 
                instr.data["z"]
            )
            pages.debug_terminal.instr_x1syringe_log(instr.stringify())
        if curr_index == len(parse.INSTRUCTIONS) -1 : 
            sending_serial = False

def cleanup_printer():
    if PRINTER_CONNECTED:  # If a printer is connected, disable the fans and the steppers.
        SER.write(str.encode("M107\r\n"))  # Fan Off
        SER.write(str.encode("M84 X Y Z S1\r\n"))  # Disable steppers

realtime_mode_checkbox = sg.Checkbox("Realtime Mode", default=False, enable_events=True, key="_realtime_mode_")

def  realtime_goto(coord, skip=False):
    x, y = coord
    global PRINTER_HEAD_POS
    prev_x, prev_y, prev_z = PRINTER_HEAD_POS
    print(parse.Z_MOVE_HEIGHT)
    if not skip:
        instructions = [parse.InstructionG01(
            pos_x=x,
            pos_y=y,
            pos_z=parse.Z_MOVE_HEIGHT,
            f=parse.MOVE_SPEED
        )]
    else:
        instructions = [
            parse.InstructionG01(
                pos_x=prev_x,
                pos_y=prev_y,
                pos_z=parse.Z_SKIP_HEIGHT,
                f=3000
            ),
            parse.InstructionG01(
                pos_x=x,
                pos_y=y,
                pos_z=parse.Z_SKIP_HEIGHT,
                f=parse.MOVE_SPEED
            ),
            parse.InstructionG01(
                pos_x=x,
                pos_y=y,
                pos_z=parse.Z_MOVE_HEIGHT,
                f=3000
            ),
        ]
    for instr in instructions:
        SER.write(str.encode(instr.stringify() + "\r\n"))
        pages.debug_terminal.debug_log("realtime mode goto: " + instr.stringify())
        if isinstance(instr, parse.InstructionG01):
            PRINTER_HEAD_POS = (
                instr.data["x"],
                instr.data["y"],
                instr.data["z"]
            )

